package figures;

public interface fillColor {
	
	void setColor(int r, int g, int b);

}
