package figures;

public interface Calcs {
	public double perimeter();
	public double area();
}
